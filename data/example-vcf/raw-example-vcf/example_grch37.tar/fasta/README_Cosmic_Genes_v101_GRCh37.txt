-------------------------
COSMIC Fasta File (genes)
-------------------------
 CDS sequence for all the coding genes in COSMIC. [ Cosmic_Genes_v101_GRCh37.fasta ]

FASTA SEQUENCE HEADER
--------------------------------------------------------------------------------------------------------
>GENE_SYMBOL TRANSCRIPT_ACCESSION CHROMOSOME:GENOME_START-GENOME_STOP(STRAND)
SEQUENCE
